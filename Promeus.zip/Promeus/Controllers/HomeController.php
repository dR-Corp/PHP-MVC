<?php

// Home controller class
class HomeController {

    public function accueil($params) {
        $view = new PublicView("accueil");
        $view->render();
    }

    public function offres($params) {
        $view = new PublicView("offres");
        $view->render();
    }

    public function offre($params) {
        // on fera la récupération de l'offre en question à ce niveau
        
        $view = new PublicView("offre");
        $view->render([
            "id" => $params["id"],
        ]);
    }

    public function entreprises($params) {
        $view = new PublicView("entreprises");
        $view->render();
    }

}