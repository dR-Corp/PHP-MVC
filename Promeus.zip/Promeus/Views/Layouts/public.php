<?php

echo $contentPage;