<!--===============================================================================================-->
<script src="<?=ASSETS?>login/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script src="<?=ASSETS?>login/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script src="<?=ASSETS?>login/vendor/bootstrap/js/popper.js"></script>
<script src="<?=ASSETS?>login/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="<?=ASSETS?>login/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="<?=ASSETS?>login/vendor/daterangepicker/moment.min.js"></script>
<script src="<?=ASSETS?>login/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="<?=ASSETS?>login/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
<script src="<?=ASSETS?>login/js/main.js"></script>