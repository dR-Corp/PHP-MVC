<?php
session_start();
include_once('_config.php');
MyAutoload::start();

if(isset($_GET['r'])) {
    $request = $_GET['r'];
    $router = new Router($request);
}
else {
    $request = $redirect = 'accueil';
    $router = new Router($request);
    $router->redirect($redirect, $request);
}

$router->renderController();