<footer class="main-footer text-center text-sm" style="border-top: 1px solid #044687;">
    <strong style="color: #044687;">Copyright &copy; <a href="http://jobbers.com" style="color: #044687;">"dR & Co"</a> 2021. Tous les droits réservés.</strong>
</footer>