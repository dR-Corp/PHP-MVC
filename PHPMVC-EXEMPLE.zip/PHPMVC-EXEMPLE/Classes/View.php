<?php


/**
 * class view
 * 
 * use to call views
 */

class View {

    private $template;

    public function __construct($template = null) {
        $this->template = $template;
    }

    public function render($params = array()) {

        // foreach($params as $name => $value) {
        //     ${name} = $value;
        // }
        extract($params); //faire une extraction de params

        $template = $this->template; // home
        
        ob_start();
        include(VIEW.$template.'.php');
        $contentPage = ob_get_clean();

        include_once(VIEW.'_template.php');

    }

    public function redirect($route) {
        header("Location: ".HOST.$route);
        exit;
    }

}