<?php

    /**
     * Server side proccesing function
     * 
     * params = dbname, user, password, host, table, array(attributes)
     * return array() with json data
     */


    function ssp_funct() {

    }

?>